﻿namespace $safeprojectname$.Pages.Repository
{
    public class TodoRepository
    { 
        public List<TODO> GetTodos()
        {
            return new List<TODO>
            {
                new TODO { Id = 1 , Name = "Zadatak 1", Description = "Opis 1 " },
                new TODO { Id = 2 , Name = "Zadatak 2", Description = "Opis 2 " },
                new TODO { Id = 3 , Name = "Zadatak 3", Description = "Opis 3 " },
                new TODO { Id = 4 , Name = "Zadatak 4", Description = "Opis 4 " },
                new TODO { Id = 5 , Name = "Zadatak 5", Description = "Opis 5 " },
            };
        }
    }
}
