﻿using $safeprojectname$.Pages.Repository;
using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    public class TodoController : Controller
    {
        private readonly TodoRepository _todoRepository;
        public TodoController()
        {
            _todoRepository = new TodoRepository();
        }
    }
}
